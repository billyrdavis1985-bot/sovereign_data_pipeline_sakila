import mysql.connector

# Set up the connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="your_password", # Replace with your actual password
    database="sakila"
)

cursor = db.cursor()

# Query the new table you just created
cursor.execute("SELECT * FROM actors_copy LIMIT 10")

print("--- Results from actors_copy ---")
for row in cursor.fetchall():
    print(row)

db.close()